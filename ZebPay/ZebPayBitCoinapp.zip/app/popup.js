var xhr = new XMLHttpRequest();
xhr.open("GET", "https://www.zebapi.com/api/v1/market/ticker/btc/inr", true);
xhr.onreadystatechange = function() {
  if (xhr.readyState == 4) {
    myFunction(xhr.responseText);
    console.log(xhr.responseText);
  }
}
xhr.send();

function myFunction(response) {
    var arr = JSON.parse(response);
    var i;
    var out = "<table>";

    out += "<tr><td>Buy</td><td>" + arr.buy +"</td></tr>" +
            "<tr><td>sell</td><td>" + arr.sell +"</td></tr>" +
            "<tr><td>volume</td><td>" + arr.volume +"</td></tr>";
    out += "</table>";
    console.log(out);
    
    document.getElementById("id01").innerHTML = out;
}


